<?php
return array(
	//'配置项'=>'配置值'
	'DB_PREFIX'=>'tp_',
	'DB_DSN'=>'mysql://cca_16574282:zwz140201011018@sql209.ccaeo.com/cca_16574282_message',
	'TMPL_L_DELIM'=>'<{',
	'TMPL_R_DELIM'=>'}>',
);
?>
