<?php
	class PublicAction extends Action{
		public function code(){
			$w=isset($_GET['w'])?$_GET['w']:80;
			$h=isset($_GET['h'])?$_GET['h']:20;
			$code->fontSize = 16; //字体大小
            $code->useNoise = true;//是否使用噪点
            
      
			import('ORG.Util.Image');
    		Image::buildImageVerify(6,1,'png',$w,$h,'code');
		}
	}
?>
