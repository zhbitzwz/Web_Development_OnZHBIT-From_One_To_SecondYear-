<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Right</title>
	<link rel="stylesheet" media="screen" href="__PUBLIC__/Css/Index/rightstyles.css" >
    <style>
    .contact_form{padding-top:40px;}
	.title {background-color:rgba(0,0,0,0.56); text-align:center; width:100%; position:fixed; top:0; left:0; padding:5px 0;}
.title a {color:#FFF; text-decoration:none; font-size:16px; font-weight:bolder; line-height:24px;}
    </style>
</head>
<body>
<div class="title"><a href="http://www.jiawin.com/forms-css3-html5-validation/">交流和分享移动互联网前沿技术</a></div>
<form class="contact_form" action="__APP__/Message/doMess" method="post" enctype='multipart/form-data' name="contact_form">
    <ul>
        <li>
             <h2>联系我们</h2>
             <span class="required_notification">* 表示必填项</span>
        </li>
        <li>
            <label for="title">留言题目:</label>
            <input type="text" name='title' placeholder="技术/论文课题" required />
			<input type='file' name='filename' />
        </li>
        <li>
            <label for="email">电子邮件:</label>
            <input type="email" name="email" placeholder="zhbitzwz@gmail.com" required />
            <span class="form_hint">正确格式为：javin@something.com</span>
        </li>
        <li>
            <label for="website">网站:</label>
            <input type="url" name="website" placeholder="http://www.zhbitzwz.ccaeo.com" required pattern="(http|https)://.+"/>
            <span class="form_hint">正确格式为：http://www.jiawin.com</span>
        </li>
        <li>
            <label for="content">留言内容:</label>
            <textarea name='content' cols="40" rows="6" placeholder="帅锅/萌妹子，对周同学有木有建议！" required ></textarea>
        </li>
        <li>
        	<button class="submit" type="submit">Submit Form</button>
        </li>
    </ul>
</form>
</body>
</html>