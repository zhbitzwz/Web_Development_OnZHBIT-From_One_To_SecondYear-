<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Top</title>

<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Index/normalize.css" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Index/demo.css" />

<!--必要样式-->
<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Index/component.css" />

<script src="__PUBLIC__/Js/Index/modernizr.custom.js"></script>

</head>
<body>

		<h1>欢迎你成功勾搭周同学</h1>
		<p>欢迎你 <?php echo (session('username')); ?> <a href='__APP__/Login/doLogout' target='_top'>退出</a></p>
<div class="slideshow" id="slideshow">
	<ol class="slides">
		<li class="current">
			<div class="description">
				<h2>Android 开发</h2>
				<p>作为 Android 领域的 Swift，绝对让你如沐新风。抛弃沉重的 Java 语法，<a href="http://www.infoq.com/cn/news/2015/06/Android-JVM-JetBrains-Kotlin">Kotlin</a>融入了很多现代编程语言的思想，作为开发者，接受新的语言，了解新语言的发展趋势，更有利于开阔你的思路和加深对语言的理解.</p>
			</div>
			<div class="tiltview col">
				<a href="#"><img src="__PUBLIC__/Images/Index/1_screen.jpg"/></a>
				<a href="#"><img src="__PUBLIC__/Images/Index/2_screen.jpg"/></a>
			</div>
		</li>
		<li>
			<div class="description">
				<h2>IOS开发</h2>
				<p>Apple 发布 OS X 10.11 El Capitan 更新和 iOS 9，改善体验和性能，同时 Swift 开源！类似微信朋友圈的富文本排版，Swift实现TableView嵌套CollectionView。<code>OS X 10.11 El Capitan</code> and <code>Swift</code>我的最爱. </p>
			</div>
			<div class="tiltview row">
				<a href="http://36kr.com/p/533679.html"><img src="__PUBLIC__/Images/Index/3_mobile.jpg"/></a>
				<a href="http://www.cocoachina.com/cms/tags.php?/Swift/"><img src="__PUBLIC__/Images/Index/4_mobile.jpg"/></a>
			</div>
		</li>
		<li>
			<div class="description">
				<h2>嵌入式</h2>
				<p>“2015 ARM ST全国大学生智能设备创新大赛”是由意法半导体（ST）、ARM 公司联合主办的面向国内大专院校及科研院所在校学生的电子设计竞赛， 旨在激发大学生设计激情，培育大学生创新意识、动手能力和工程实践能力。</p>
			</div>
			<div class="tiltview col">
				<a href="#"><img src="__PUBLIC__/Images/Index/5_screen.jpg"/></a>
				<a href="#"><img src="__PUBLIC__/Images/Index/6_screen.jpg"/></a>
			</div>
		</li>
		<li>
			<div class="description">
				<h2>智能硬件</h2>
				<p>Jibo是科学家Dr. Cynthia Breazeal开发的社交机器人。虽然它离正式发售还有将近一年的时间，但Breazeal和她的团队终于做出了一个工程机，有开发者开源，提供的机器人仍然支持语音指令、活动（躯干和头部可以移动，但机器人不会滚动）、拍照、人脸识别、触控这些功能！</p>
			</div>
			<div class="tiltview row">
				<a href="#"><img src="__PUBLIC__/Images/Index/1_mobile.jpg"/></a>
				<a href="#"><img src="__PUBLIC__/Images/Index/2_mobile.jpg"/></a>
			</div>
		</li>
		<li>
			<div class="description">
				<h2>眼球博客人</h2>
				<p>加拿大电影工作者罗布-思朋斯，他童年遭受右眼意外事故之外，它的右眼又获得了新生，在工程师们的帮助下，他的右眼不仅变成了摄像机，还成了像《终结者》中机械人般的红色机械眼。</p>
			</div>
			<div class="tiltview col">
				<a href="#"><img src="__PUBLIC__/Images/Index/3_screen.jpg"/></a>
				<a href="#"><img src="__PUBLIC__/Images/Index/4_screen.jpg"/></a>
			</div>
		</li>
		<li>
			<div class="description">
				<h2>最遥远的距离</h2>
				<p>世界上最遥远的距离，不是生与死 而是科技就站在你面前 你却不知道如何触及它。世界因你的开发而精彩！</p>
			</div>
			<div class="tiltview row">
				<a href="#"><img src="__PUBLIC__/Images/Index/5_mobile.jpg"/></a>
				<a href="#"><img src="__PUBLIC__/Images/Index/6_mobile.jpg"/></a>
			</div>
		</li>
	</ol>
</div>

<script type="text/javascript" src="__PUBLIC__/Js/Index/classie.js"></script>
<script type="text/javascript" src="__PUBLIC__/Js/Index/tiltSlider.js"></script>
<script type="text/javascript">
new TiltSlider(document.getElementById('slideshow'));
</script>
<div style="text-align:center;margin:50px 0; font:normal 14px/24px 'MicroSoft YaHei';"></div>
</body>
</html>