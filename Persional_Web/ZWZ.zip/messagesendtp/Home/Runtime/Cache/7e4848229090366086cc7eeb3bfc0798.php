<?php if (!defined('THINK_PATH')) exit();?><html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<title>Index</title>
	</head>
	<frameset rows='20%,*'>
		<frame src='__URL__/top' name='top'/>
		<frameset cols='50%,50%'>
			<frame src='__URL__/left' name='left'/>
			<frame src='__URL__/right' name='right'/>
		</frameset>
	</frameset>
</html>