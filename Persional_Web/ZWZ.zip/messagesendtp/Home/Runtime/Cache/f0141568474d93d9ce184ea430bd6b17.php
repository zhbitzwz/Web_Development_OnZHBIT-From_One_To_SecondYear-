<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<title>Login</title>
		<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/basic.css" />
		<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Home/login.css" />
		<script type="text/javascript" src="__PUBLIC__/Js/jquery.js"></script>
		<title>login</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<!--webfonts-->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,300,600,700' rel='stylesheet' type='text/css'>
		<!--//webfonts-->
	</head>
	<body>
		<!-----start-main---->
	 <div class="main">
		<div class="login-form">
			<h1>欢迎拜访周同学</h1>
					<div class="head">
						<img src="__PUBLIC__/Images/user.png" alt=""/>
					</div>
				<form action='__URL__/doLogin' method='post' name='myForm'>
						<input type="text" name='username' class="text" value="username" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'username';}" >
						<input type="password"  name='password' value="Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}">
						<input type="text0"  name='code' value="验证码" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '验证码';}">
					            <img src='__APP__/Public/code?w=80&h=35' onclick='this.src=this.src+"?"+Math.random()'/>
					<br/>
						<div class="submit">
							<input type="submit" onclick="myFunction()" value="LOGIN" >
					</div>	
					<p><a href="__APP__/Register/reg">还没注册?</a></p>
				</form>
			</div>
			<!--//End-login-form-->
			 <!-----start-copyright---->
   					<div class="copy-right">
						<p>返回官网<a href="http://zhbitzwz.ccaeo.com/">ZHBITZWZ</a></p> 
					</div>
				<!-----//end-copyright---->
		</div>
			 <!-----//end-main---->
	</body>
</html>