<?php
	class Test{
		public $k='赵桐正！！';
	}
?>
