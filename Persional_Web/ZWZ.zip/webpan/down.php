<?php
	error_reporting(NULL);
	Header("Content-type: application/octet-stream"); 
	Header("Content-Disposition: attachment; filename=".$_GET['filename']);
?>