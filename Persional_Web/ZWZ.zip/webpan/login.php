<?php
	error_reporting(NULL);
	session_start();
	setcookie(session_name(),session_id());
	$link=mysql_connect('sql209.ccaeo.com','cca_16574282','zwz140201011018');
	mysql_select_db('cca_16574282_zwz',$link);
	$username=$_POST['login_name'];
	$sql="SELECT password FROM phppan WHERE username='{$username}'";
	$res=mysql_query($sql,$link);
	$arr=mysql_fetch_assoc($res);
	if($arr['password']!==$_POST['login_password']){
		echo "<h1>登录失败</h1>";
		echo "用户名或者密码错误，请重新<a href=login.html>登录</a>";
	}else{
		$_SESSION['username']=$username;
		$_SESSION['dir']=$username;
		echo '<h1>登录成功</h1>';
		echo '马上跳转至管理页面...';
		echo "<meta http-equiv=\"refresh\" content=\"1;url=managefile.php\">";
	}
?>