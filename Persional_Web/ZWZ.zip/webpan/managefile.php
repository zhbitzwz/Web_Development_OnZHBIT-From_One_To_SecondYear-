<?php
	error_reporting(NULL);
	session_start();
	// echo "当前目录是".$_SESSION['dir'].'<br />';
	if(isset($_GET['back'])&&($_GET['back']=='yes'))
		$_SESSION['dir']=substr($_SESSION['dir'],0,strripos($_SESSION['dir'],'/'));	
	if(isset($_GET['dir'])){
		$_SESSION['dir'].="/{$_GET['dir']}";		//加目录
		chdir("../{$_SESSION['dir']}");	//变目录		
	}else
		chdir("../{$_SESSION['dir']}");//展示主目录
	if($_SESSION['dir']!=$_SESSION['username'])	//判断是否需要返回
		echo "<a href=managefile.php?back=yes>返回上一级</a><br />";
	$arr=scandir(getcwd());		//将当前目录作为scandir函数的参数
	echo "<table>";
	foreach($arr as $v){		//遍历数组
		if(is_dir("./{$v}")&&$v!='.'&&$v!='..')
			echo "<tr><a href=managefile.php?dir={$v}>{$v}</a></tr>";
		elseif(is_file($v)){
			echo "<tr><td>{$v}</td><td><a href=down.php?filename={$v}>下载</tr>";
		}
	}
	echo "</table>";
?>
<form enctype='multipart/form-data' method='post'>
	<input type='file' name='usrfile' />
	<input type='submit' value='上传'>
</form>
<?php
	if(!empty($_FILES)){		//判断变量是否为空
		$filename=$_FILES['usrfile']['tmp_name'];		//定义要转移的文件名
		$filedir="../{$_SESSION['dir']}/{$_FILES['usrfile']['name']}";		//定义目标路径
		move_uploaded_file($filename,$filedir);
		echo "<meta http-equiv=\"refresh\" content=\"0;url=managefile.php\">";
	}else{
	}
?>
