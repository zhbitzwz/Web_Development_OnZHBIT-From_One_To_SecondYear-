<?php
	error_reporting(NULL);
	$link=mysql_connect('sql209.ccaeo.com','cca_16574282','zwz140201011018')or die("数据库连接失败！");
	mysql_select_db('cca_16574282_zwz',$link);
	$username=$_POST['username'];
	$psw=$_POST['password'];
	$sql="SELECT * FROM phppan WHERE username='{$username}'";
	$res=mysql_query($sql,$link)or die("查询失败".mysql_error($link));
	$arr=mysql_num_rows($res);
	if(empty($username)||empty($psw)){
		echo '<h1>警告</h1>';
		echo '用户名或密码都不可以为空，请<a href=register.html>重新填写</a>';
	}elseif($arr!=NULL)
		echo '该用户名已经被抢注，请<a href=register.html>重新填写</a>';
	elseif(!empty($username)&&!empty($psw)){
		$sql="INSERT phppan(username,password) VALUES('{$username}','{$psw}')";
		mysql_query($sql,$link)or die('数据库出现问题！'.mysql_error($link));
		echo "账号注册成功！现在你可以去<a href=login.html>登录</a>";
		mkdir("../{$username}");
	}
?>