<?php
	session_start();
	if(!empty($_FILES)){		//判断变量是否为空
		$filename=$_FILES['usrfile']['tmp_name'];		//定义要转移的文件名
		$filedir="../{$_SESSION['dir']}/{$_FILES['usrfile']['name']}";		//定义目标路径
		move_uploaded_file($filename,$filedir);
		echo "<meta http-equiv=\"refresh\" content=\"0;url=managefile.php\">";
	}
?>
<form enctype='multipart/form-data' method='post'>
	<input type='file' name='usrfile' />
	<input type='submit' value='上传'>
</form>